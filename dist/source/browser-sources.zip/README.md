# Browser companions

These are the self-contained Haskell sources used by the inline figures.
The browser adapter uses base, containers, mtl, and transformers.
Built with GHC 9.14.1.20260731 for wasm32-wasi. From this directory:

```sh
wasm32-wasi-ghc -O2 -ihaskell haskell/Browser.hs -no-hs-main -optl-mexec-model=reactor -optl-Wl,--export=hs_init,--export=malloc,--export=free,--export=crc_direct,--export=crc_remainder,--export=crc_factor,--export=crc_multiply,--export=crc_combine,--export=crc_finish,--export=automaton_step,--export=image_demo,--export=binding_demo,--export=morton_demo,--export=ad_demo,--export=lca_demo -o crc.wasm
```

The JavaScript host uses @bjorn3/browser_wasi_shim 0.4.2 and calls hs_init(0,0).
JSON results from binding_demo, morton_demo, ad_demo, lca_demo, and image_demo are UTF-8 C strings; free them after use.
Server.hs is a separate native CRC example and requires wai and warp.
